public enum EventType{
    MOVE_BUS(1);

    int type;
    EventType(int atype){
        type = atype;
    }

}