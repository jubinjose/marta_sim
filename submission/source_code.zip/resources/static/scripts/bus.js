class Bus {
    constructor(id, current_stop_id, arrival_time, status, rider_count, route_id, capacity, speed) {
        this.id = id;
        this.current_stop_id = current_stop_id;
        this.arrival_time = arrival_time;
        this.status = status;
        this.rider_count = rider_count;
        this.route_id = route_id;
        this.capacity = capacity;
        this.speed = speed;
    }
}
